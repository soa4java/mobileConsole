package net.dongliu.apk.parser.bean;

/**
 * @author Dong Liu
 */
public class IntentFilter {

}
