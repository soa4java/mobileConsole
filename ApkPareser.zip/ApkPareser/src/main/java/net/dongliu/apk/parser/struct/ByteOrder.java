package net.dongliu.apk.parser.struct;

/**
 * @author dongliu
 */
public enum ByteOrder {
    BIG, LITTLE
}
